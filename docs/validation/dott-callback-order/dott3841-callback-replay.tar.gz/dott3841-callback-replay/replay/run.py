"""Replay exact production callback ordering; no Gradle, Android, Binder, or device."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent.parent)
parser.add_argument('--jdk-home', type=Path, required=True,
                    help='Installed JDK 17 directory containing bin/java and bin/javac')
parser.add_argument('--kotlin-lib', type=Path, required=True,
                    help='Installed Gradle 8.13 lib directory with Kotlin 2.0.21 compiler/runtime jars')
args = parser.parse_args()
root = args.root
lib = args.kotlin_lib
jdk = args.jdk_home / 'bin'
package = Path('play-services-droidguard/core/src/main/kotlin/org/microg/gms/droidguard/core')
compiler_cp = ':'.join(str(lib / name) for name in [
    'kotlin-compiler-embeddable-2.0.21.jar', 'kotlin-stdlib-2.0.21.jar',
    'kotlin-script-runtime-2.0.21.jar', 'kotlin-reflect-2.0.21.jar',
    'trove4j-1.0.20200330.jar', 'kotlinx-coroutines-core-jvm-1.6.4.jar',
    'annotations-24.0.1.jar',
])
runtime_cp = ':'.join(str(lib / name) for name in [
    'kotlin-stdlib-2.0.21.jar', 'annotations-24.0.1.jar',
])


def run(name, command, expected=(0,), timeout=60):
    result = subprocess.run(list(map(str, command)), stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, timeout=timeout)
    (root / f'{name}.log').write_text(result.stdout)
    print(f'{name}: exit={result.returncode}', flush=True)
    if result.returncode not in expected:
        print(result.stdout, flush=True)
        raise RuntimeError(f'{name} failed')
    return result


stub_classes = root / 'replay/stub-classes'
stub_classes.mkdir(exist_ok=True)
run('stubs-compile', [jdk / 'javac', '-d', stub_classes,
    *sorted((root / 'replay/stubs').rglob('*.java'))])
hashes = {}
for variant in ('original', 'candidate'):
    sources = sorted((root / variant / package).glob('*.kt'))
    hashes[variant] = {str(path.relative_to(root / variant)):
        hashlib.sha256(path.read_bytes()).hexdigest() for path in sources}
    run(f'{variant}-compile', [jdk / 'java', '-Xmx384m', f'-Djava.io.tmpdir={root}',
        '-cp', compiler_cp, 'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler',
        '-no-stdlib', '-no-reflect', '-classpath', f'{stub_classes}:{runtime_cp}',
        '-jvm-target', '1.8', '-d', root / f'{variant}.jar', *sources])

replay_classes = root / 'replay/classes'
replay_classes.mkdir(exist_ok=True)
run('replay-compile', [jdk / 'javac', '--add-modules', 'jdk.httpserver', '-cp',
    f'{stub_classes}:{root}/original.jar:{runtime_cp}', '-d', replay_classes,
    root / 'replay/DroidGuardCallbackReplay.java'])

outcomes = {}
for variant in ('original', 'candidate'):
    result = run(f'{variant}-replay', [jdk / 'java', '-Xmx128m', '--add-modules', 'jdk.httpserver',
        '-cp', f'{replay_classes}:{stub_classes}:{root}/{variant}.jar:{runtime_cp}',
        'DroidGuardCallbackReplay'], expected=(0, 1), timeout=20)
    print(result.stdout, flush=True)
    median = re.search(r'LATENCY_MEDIAN .*snapshot_send_to_callback_ms=([\d.]+)', result.stdout)
    outcomes[variant] = {'exit_code': result.returncode,
        'summary': result.stdout.splitlines()[-1],
        'controlled_300ms_cleanup_median_ms': float(median[1]) if median else None}

(root / 'replay-results.json').write_text(json.dumps({
    'base': '7a648d5fe5f073c61ef7b202aef4c74dd329f4be',
    'service_blob': 'e8336a1fb3a613a03d214fd50255b84cb2c5a364',
    'boundary': 'Exact full production service and RemoteHandle/initialization/session/HTTP/fallback Kotlin; real local HTTP. Disposable Android/AIDL/context/preference stubs, Network mode only. Not Android, Binder, a production server, or physical Dott acceptance.',
    'source_sha256': hashes, 'results': outcomes,
}, indent=2) + '\n')
if outcomes['original']['exit_code'] != 1 or outcomes['candidate']['exit_code'] != 0:
    raise SystemExit('Expected the existing source to expose the ordering failure and the fix to pass.')
