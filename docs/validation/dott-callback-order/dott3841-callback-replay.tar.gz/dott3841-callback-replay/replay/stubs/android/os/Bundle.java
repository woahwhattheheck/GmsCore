package android.os;
public class Bundle {
    private final java.util.Map<String, Object> fields = new java.util.LinkedHashMap<>();
    public java.util.Set<String> keySet() { return fields.keySet(); }
    public int size() { return fields.size(); }
    public Object get(String key) { return fields.get(key); }
    public void putString(String key, String value) { fields.put(key, value); }
    public void putInt(String key, int value) { fields.put(key, value); }
    public int getInt(String key, int fallback) {
        Object value = fields.get(key);
        return value instanceof Integer ? (Integer) value : fallback;
    }
}
