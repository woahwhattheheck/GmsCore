package android.util;
public final class Log {
    public static int d(String tag, String message) { return 0; }
    public static int w(String tag, String message, Throwable error) { return 0; }
    public static int w(String tag, String message) { return 0; }
    public static int w(String tag, Throwable error) { return 0; }
}
