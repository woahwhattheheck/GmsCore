package android.os;
public class ParcelFileDescriptor implements java.io.Closeable {
    public void close() throws java.io.IOException {}
}
