package com.google.android.gms.droidguard.internal;
public interface IDroidGuardCallbacks {
    void onResult(byte[] result);
}
