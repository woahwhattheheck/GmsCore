package com.google.android.gms.droidguard.internal;
public interface IDroidGuardService {
    void guard(IDroidGuardCallbacks callbacks, String flow, java.util.Map map);
    void guardWithRequest(IDroidGuardCallbacks callbacks, String flow, java.util.Map map, DroidGuardResultsRequest request);
    IDroidGuardHandle getHandle();
    int getClientTimeoutMillis();
    abstract class Stub implements IDroidGuardService {}
}
