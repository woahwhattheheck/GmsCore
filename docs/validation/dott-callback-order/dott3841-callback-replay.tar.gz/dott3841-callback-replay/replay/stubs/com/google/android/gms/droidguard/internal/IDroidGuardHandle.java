package com.google.android.gms.droidguard.internal;
public interface IDroidGuardHandle {
    void init(String flow);
    byte[] snapshot(java.util.Map map);
    void close();
    DroidGuardInitReply initWithRequest(String flow, DroidGuardResultsRequest request);
    abstract class Stub implements IDroidGuardHandle {}
}
