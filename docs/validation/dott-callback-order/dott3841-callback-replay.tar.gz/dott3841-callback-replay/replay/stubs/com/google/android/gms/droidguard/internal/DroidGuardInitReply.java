package com.google.android.gms.droidguard.internal;
public final class DroidGuardInitReply {
    public android.os.ParcelFileDescriptor pfd;
}
