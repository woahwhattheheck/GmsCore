package com.google.android.gms.droidguard.internal;
public final class DroidGuardResultsRequest {
    public android.os.Bundle bundle = new android.os.Bundle();
    public int getTimeoutMillis() { return bundle.getInt("timeoutMs", 60000); }
    public DroidGuardResultsRequest setTimeoutMillis(int timeout) {
        bundle.putInt("timeoutMs", timeout);
        return this;
    }
}
