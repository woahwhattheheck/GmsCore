package org.microg.gms.droidguard.core;
public final class DroidGuardPreferences {
    public enum Mode { Embedded, Network }
    public static String endpoint;
    public static Mode getMode(android.content.Context context) { return Mode.Network; }
    public static String getNetworkServerUrl(android.content.Context context) { return endpoint; }
}
