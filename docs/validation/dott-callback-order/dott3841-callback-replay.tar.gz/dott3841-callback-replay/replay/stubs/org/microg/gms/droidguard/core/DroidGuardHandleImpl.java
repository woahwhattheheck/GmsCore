package org.microg.gms.droidguard.core;
import com.google.android.gms.droidguard.internal.*;
/** Embedded mode is never selected by this Network-only replay. */
public final class DroidGuardHandleImpl implements IDroidGuardHandle {
    public DroidGuardHandleImpl(android.content.Context context, String packageName, Object factory, Object callback) {
        throw new AssertionError("Unexpected embedded mode");
    }
    public void init(String flow) { throw new AssertionError(); }
    public byte[] snapshot(java.util.Map map) { throw new AssertionError(); }
    public void close() { throw new AssertionError(); }
    public DroidGuardInitReply initWithRequest(String flow, DroidGuardResultsRequest request) { throw new AssertionError(); }
}
