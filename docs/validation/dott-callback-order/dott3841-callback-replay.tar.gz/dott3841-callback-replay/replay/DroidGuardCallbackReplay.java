import com.google.android.gms.droidguard.DroidGuardChimeraService;
import com.google.android.gms.droidguard.internal.DroidGuardResultsRequest;
import com.sun.net.httpserver.HttpServer;
import org.microg.gms.droidguard.core.DroidGuardPreferences;
import org.microg.gms.droidguard.core.DroidGuardServiceImpl;

import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/** Actual service/remote-session Kotlin and real HTTP, with disposable platform stubs. */
public final class DroidGuardCallbackReplay {
    private static final List<Boolean> results = new ArrayList<>();

    public static void main(String[] args) throws Exception {
        blockedCleanup(false);
        blockedCleanup(true);
        callbackFailureStillCloses();
        rejectedRequestDeliversOnce();
        controlledCleanupLatency();
        long passed = results.stream().filter(Boolean::booleanValue).count();
        System.out.println("SUMMARY passed=" + passed + " total=" + results.size());
        System.exit(passed == results.size() ? 0 : 1);
    }

    private static DroidGuardServiceImpl service(Server server, ExecutorService worker) {
        DroidGuardPreferences.endpoint = server.url();
        DroidGuardChimeraService context = new DroidGuardChimeraService();
        context.d = worker;
        return new DroidGuardServiceImpl(context, "example.fixture.app");
    }

    private static void blockedCleanup(boolean failSnapshot) throws Exception {
        ExecutorService worker = Executors.newSingleThreadExecutor();
        try (Server server = new Server(true, 0, failSnapshot)) {
            AtomicInteger callbacks = new AtomicInteger();
            AtomicReference<String> output = new AtomicReference<>();
            service(server, worker).guardWithRequest(bytes -> {
                output.set(new String(bytes, StandardCharsets.UTF_8));
                callbacks.incrementAndGet();
            }, "ad_attest", Collections.singletonMap("rpc", "challenge"), request());
            Future<?> finished = worker.submit(() -> {});
            require(server.closeStarted.await(2, TimeUnit.SECONDS), "close did not start");
            boolean deliveredBeforeRelease = callbacks.get() == 1;
            boolean cleanupStillBlocked = !finished.isDone();
            server.releaseClose.countDown();
            finished.get(3, TimeUnit.SECONDS);
            String expected = failSnapshot ? "ERROR : no fallback for ad_attest" : "READY";
            report(failSnapshot ? "fallback_before_blocked_close" : "success_before_blocked_close",
                deliveredBeforeRelease && cleanupStillBlocked && callbacks.get() == 1
                    && server.closes.get() == 1 && expected.equals(output.get()),
                "callback_before_release=" + deliveredBeforeRelease
                    + " cleanup_blocked=" + cleanupStillBlocked + " callbacks=" + callbacks.get()
                    + " closes=" + server.closes.get() + " payload=" + output.get());
        } finally {
            worker.shutdownNow();
            worker.awaitTermination(2, TimeUnit.SECONDS);
        }
    }

    private static void callbackFailureStillCloses() throws Exception {
        ExecutorService worker = Executors.newSingleThreadExecutor();
        try (Server server = new Server(false, 0, false)) {
            AtomicInteger callbacks = new AtomicInteger();
            service(server, worker).guardWithRequest(bytes -> {
                callbacks.incrementAndGet();
                throw new IllegalStateException("controlled callback failure");
            }, "ad_attest", Collections.emptyMap(), request());
            worker.submit(() -> {}).get(3, TimeUnit.SECONDS);
            report("callback_failure_cleanup_control", callbacks.get() == 1 && server.closes.get() == 1,
                "callbacks=" + callbacks.get() + " closes=" + server.closes.get());
        } finally {
            worker.shutdownNow();
            worker.awaitTermination(2, TimeUnit.SECONDS);
        }
    }

    private static void rejectedRequestDeliversOnce() {
        DroidGuardChimeraService context = new DroidGuardChimeraService();
        context.d = task -> { throw new RejectedExecutionException("controlled full queue"); };
        AtomicInteger callbacks = new AtomicInteger();
        AtomicReference<String> output = new AtomicReference<>();
        new DroidGuardServiceImpl(context, "example.fixture.app").guardWithRequest(bytes -> {
            callbacks.incrementAndGet();
            output.set(new String(bytes, StandardCharsets.UTF_8));
        }, "ad_attest", Collections.emptyMap(), request());
        report("queue_rejection_control", callbacks.get() == 1
                && "ERROR : no fallback for ad_attest".equals(output.get()),
            "callbacks=" + callbacks.get() + " payload=" + output.get());
    }

    private static void controlledCleanupLatency() throws Exception {
        List<Double> deliveryTimes = new ArrayList<>();
        for (int sample = 0; sample < 3; sample++) {
            ExecutorService worker = Executors.newSingleThreadExecutor();
            try (Server server = new Server(false, 300, false)) {
                AtomicLong delivered = new AtomicLong();
                AtomicInteger callbacks = new AtomicInteger();
                service(server, worker).guardWithRequest(bytes -> {
                    delivered.set(System.nanoTime());
                    callbacks.incrementAndGet();
                }, "ad_attest", Collections.emptyMap(), request());
                worker.submit(() -> {}).get(3, TimeUnit.SECONDS);
                require(callbacks.get() == 1 && server.closes.get() == 1, "benchmark request incomplete");
                double millis = (delivered.get() - server.snapshotSent.get()) / 1_000_000.0;
                deliveryTimes.add(millis);
                System.out.printf(java.util.Locale.ROOT,
                    "LATENCY sample=%d cleanup_delay_ms=300 snapshot_send_to_callback_ms=%.3f%n", sample + 1, millis);
            } finally {
                worker.shutdownNow();
                worker.awaitTermination(2, TimeUnit.SECONDS);
            }
        }
        Collections.sort(deliveryTimes);
        System.out.printf(java.util.Locale.ROOT,
            "LATENCY_MEDIAN cleanup_delay_ms=300 snapshot_send_to_callback_ms=%.3f%n", deliveryTimes.get(1));
    }

    private static DroidGuardResultsRequest request() {
        return new DroidGuardResultsRequest().setTimeoutMillis(2_000);
    }

    private static void report(String name, boolean passed, String details) {
        results.add(passed);
        System.out.println("CASE " + name + " " + (passed ? "PASS" : "FAIL") + " " + details);
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static final class Server implements AutoCloseable {
        final ExecutorService connections = Executors.newCachedThreadPool();
        final CountDownLatch closeStarted = new CountDownLatch(1);
        final CountDownLatch releaseClose;
        final AtomicInteger closes = new AtomicInteger();
        final AtomicLong snapshotSent = new AtomicLong();
        final HttpServer server;

        Server(boolean holdClose, int delayCloseMillis, boolean failSnapshot) throws Exception {
            releaseClose = new CountDownLatch(holdClose ? 1 : 0);
            server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
            server.setExecutor(connections);
            server.createContext("/droidguard", exchange -> {
                String action = "legacy";
                for (String pair : exchange.getRequestURI().getRawQuery().split("&")) {
                    String[] field = pair.split("=", 2);
                    if (field[0].equals("action")) action = URLDecoder.decode(field[1], StandardCharsets.UTF_8);
                }
                exchange.getRequestBody().readAllBytes();
                String output;
                int status = 200;
                if (action.equals("begin")) output = "sessionId=fixture-session";
                else if (action.equals("snapshot")) {
                    output = Base64.getUrlEncoder().encodeToString("READY".getBytes(StandardCharsets.UTF_8));
                    if (failSnapshot) { status = 503; output = "controlled snapshot failure"; }
                } else if (action.equals("close")) {
                    closes.incrementAndGet();
                    closeStarted.countDown();
                    try {
                        require(releaseClose.await(5, TimeUnit.SECONDS), "close release missing");
                        if (delayCloseMillis > 0) Thread.sleep(delayCloseMillis);
                    } catch (InterruptedException interrupted) {
                        Thread.currentThread().interrupt();
                        exchange.close();
                        return;
                    }
                    output = "ok";
                } else { status = 500; output = "unexpected legacy request"; }
                byte[] body = output.getBytes(StandardCharsets.UTF_8);
                exchange.sendResponseHeaders(status, body.length);
                if (action.equals("snapshot")) snapshotSent.set(System.nanoTime());
                exchange.getResponseBody().write(body);
                exchange.close();
            });
            server.start();
        }

        String url() { return "http://127.0.0.1:" + server.getAddress().getPort() + "/droidguard"; }

        @Override public void close() throws Exception {
            releaseClose.countDown();
            server.stop(0);
            connections.shutdownNow();
            connections.awaitTermination(2, TimeUnit.SECONDS);
        }
    }
}
